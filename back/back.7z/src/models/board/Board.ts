interface Board {
    id: string;
    ownerId:string;
    name:string;

  }
  
  export { Board };
  